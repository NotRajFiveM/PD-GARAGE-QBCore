fx_version 'adamant'

game 'gta5'

description 'Cum'

client_scripts {
	'client/main.lua'
}

shared_script 'Config.lua'


lua54 'yes'
nore {
   	 
}