Config = {}

Config.Pedlocation = {
    {Cords = vector3(441.41162, -974.6804, 24.699926), h = 172.08871}  -- NPC Spawn Location.
}